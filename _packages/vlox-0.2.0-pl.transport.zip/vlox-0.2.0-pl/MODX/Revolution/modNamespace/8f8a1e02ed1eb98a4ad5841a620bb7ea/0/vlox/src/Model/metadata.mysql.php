<?php
$xpdo_meta_map = array (
    'version' => '3.0',
    'namespace' => 'Vlox\\Model',
    'namespacePrefix' => 'Vlox',
    'class_map' => 
    array (
        'xPDO\\Om\\xPDOSimpleObject' => 
        array (
            0 => 'Vlox\\Model\\VloxResourceContent',
            1 => 'Vlox\\Model\\VloxFragments',
        ),
    ),
);