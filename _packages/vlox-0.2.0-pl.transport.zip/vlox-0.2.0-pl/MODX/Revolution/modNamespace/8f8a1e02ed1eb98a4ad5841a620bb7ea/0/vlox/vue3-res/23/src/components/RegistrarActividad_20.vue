<script setup>
  import {ref, onMounted, inject} from 'vue'
  import axios from 'axios'
  import {useQuasar} from 'quasar'
  import imageCompression from 'browser-image-compression'
  import { useI18n } from 'vue-i18n'

  const axiosConfig = {
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Access-Control-Allow-Origin': '*'
    }
  };

  const $q = useQuasar()


  const formState = ref({
    supervisor_id: 666,
    worker_id: 0,
    in_date: new Date()
      .toLocaleString('es-CO', {dateStyle: 'medium', timeStyle: 'short', hour12: true}),
    out_date: 0,
    in_photo_check: '',
    out_photo_check: '',
    project_id: 0,
    in_coordinates: {},
    out_coordinates: {},
    in_photo_location: '',
    out_photo_location: ''
  });
  
  const compressOptions = {
    fileType: 'image/jpeg',
    maxSizeMB: 0.5,
    maxIteration: 100,
  };

  const newIngreso = ref(false)
  const supervisorModal = ref(false)
  const exitModal = ref(false)
  const confirmCreate = ref(false)
  const confirmExit = ref(false)
  const users = ref([])
  const projects = ref([])
  const attendance = ref([])
  const userOptions = ref([])
  const location = ref({})
  //configuration constants
  const wsRoute = inject('wsroute')
  const assetsRoute = inject('assetsRoute')
  const mapBoxKey = inject('mapBoxKey')
  const mapBoxbaseUrl = "https://api.mapbox.com/styles/v1/mapbox/satellite-streets-v11/static/pin-l+ff0000"
  const mapImgUrl = ref("")
  const { t } = useI18n()
  
  let originalOptions = []
  let projectsOriginalOptions = []
  let locationImgBlob
  const originalLocationImages = {
    in: '',
    out: ''
  }

  onMounted(() => {
    loadAttendance()
    loadUsers()
    //loadLocation()
    loadProjects()
  })

  function submitForm() {
    confirmCreate.value = true;
  }

  async function uploadFile(photo, worker_id) {
    console.log('before if')
    if (photo instanceof File || photo instanceof Blob) {
      //first we compress the picture
      //compressOptions
      console.log('before compresing')
      const compressedFile = await imageCompression(photo, compressOptions)  
      console.log('after compresing')
      //we load the picture
      const form_data = new FormData();
      form_data.append("file", compressedFile, compressedFile.name ? compressedFile.name : Date.now() + '.jpg')
      form_data.append("worker_id", worker_id)
      console.log('before sending')
      const fileResponse = await axios({
        method: "post",
        url: window.location.protocol + "//" + window.location.hostname  + wsRoute + "?_rest=Files",
        data: form_data
      }, axiosConfig);
      console.log('sent')
      if (fileResponse.data && fileResponse.data.message) {
        return fileResponse.data.message.substring(13);
      } else {
        return '';
      }
    }
  }

  async function saveAttendance(mode) {
    console.log('starting save')
    confirmCreate.value = false
    confirmExit.value = false
    const objectToStore = formState._rawValue
    objectToStore.worker_id = !isNaN(objectToStore.worker_id) ? objectToStore.worker_id : objectToStore.worker_id.id
    if (mode === 0) {
      objectToStore.in_date = new Date().toJSON()
      if (!objectToStore.worker_id || !objectToStore.in_photo_check 
              || !objectToStore.in_photo_location || !objectToStore.in_coordinates 
              || Object.keys(objectToStore.in_coordinates).length === 0 ) {
        $q.dialog({
          title: t('error_title'),
          message: t('mng_act_select_create_entry_error')
        })
        return
      }
    } else {
      objectToStore.out_date = new Date().toJSON();
      if (!objectToStore.out_photo_check || !objectToStore.out_photo_location || !objectToStore.out_coordinates 
              || Object.keys(objectToStore.out_coordinates).length === 0) {
        $q.dialog({
          title: t('error_title'),
          message: t('mng_act_select_person_picture_error')
        })
        return
      }
    }
    console.log('before showing the loading thing')
    $q.loading.show({
      delay: 400, // ms
      message: t('global_saving')
    })
    try {
      //first we check if we have a file and upload it
      let photo_check = (mode === 0 ? objectToStore.in_photo_check : objectToStore.out_photo_check)
      console.log('before 1st picture')
      let photoUrl = await uploadFile(photo_check, objectToStore.worker_id)
      photoUrl = window.location.protocol + "//" + window.location.hostname + photoUrl
      console.log('after 1st picture')
      objectToStore[mode === 0 ? 'in_photo_check' : 'out_photo_check'] = photoUrl
      //Now we process the location picture
      photo_check = (mode === 0 ? originalLocationImages.in : originalLocationImages.out);
      console.log('before 2st picture')
      photoUrl = await uploadFile(photo_check, objectToStore.worker_id)
      console.log('after 2st picture')
      //objectToStore.in_photo_check =
      objectToStore[mode === 0 ? 'in_photo_location' : 'out_photo_location'] =
        window.location.protocol + "//" + window.location.hostname + photoUrl
      
      objectToStore.project_id = objectToStore.project_id.id
      
      const response = await axios({
        method: mode === 0 ? "post" : "put",
        url: window.location.protocol + "//" + window.location.hostname  + wsRoute + "?_rest=Attendance",
        data: objectToStore
      }, axiosConfig)
      $q.loading.hide()
      if (typeof response.data === 'string' && response.data.includes('Fatal error')) {
        $q.dialog({
          title: '¡Error!',
          message: t('fatal_error_body') 
        })
        return;
      } 
      
      await loadAttendance()
      $q.dialog({
        title: t('global_success'),
        message: t('mng_act_entry_success')
      })
      if (mode === 0) {
        newIngreso.value = false
      } else {
        exitModal.value = false;
      }
      formState.value = {
        supervisor_id: 19,
        worker_id: 0,
        in_date: new Date().toLocaleString(),
        out_date: 0,
        in_photo_check: '',
        out_photo_check: '',
      }

    } catch (error) {
      $q.loading.hide()
      processError(error)
      
    }
  }

  async function loadUsers() {
    try {
      const response = await axios({
        method: 'get',
        url: window.location.protocol + "//" + window.location.hostname  + wsRoute + "?_rest=SystemUsers"
      }, axiosConfig)
      users.value = response.data.results
      originalOptions = response.data.results
    } catch (error) {
      processError(error)
    }
  }
  
  async function loadProjects() {
    try {
      const response = await axios({
        method: 'get',
        url: window.location.protocol + "//" + window.location.hostname  + wsRoute + "?_rest=Projects"
      }, axiosConfig)
      projects.value = response.data.results
      projectsOriginalOptions = response.data.results
    } catch (error) {
      processError(error)
    }
  }

  async function loadAttendance() {
    try {
      const response = await axios({
        method: 'get',
        url: window.location.protocol + "//" + window.location.hostname  + wsRoute + "?_rest=Attendance/666"
      }, axiosConfig)
      let results = response.data.results.filter((val) => val.out_date === 0)
      attendance.value = results
      originalOptions = results
    } catch (error) {
      processError(error)
    }
  }

  function addedFile(files, mode) {
    if (mode === 0) {
      formState.value.in_photo_check = files[0]
    } else {
      formState.value.out_photo_check = files[0]
    }
  }

  function filterFn(val, update, abort) {
    update(() => {
      const needle = val.toLowerCase()
      users.value = originalOptions.filter(v => v.fullname.toLowerCase().indexOf(needle) > -1)
    })
  }

  function validateEmail(email) {
    return /[a-z0-9]+@[a-z]+\.[a-z]{2,3}/.test(email);
  }

  function longToDateTime(time) {
    return new Date(time * 1000)
      .toLocaleString('es-CO', {dateStyle: 'medium', timeStyle: 'short', hour12: true})
  }

  function registerWorkerExit(entry) {
    formState.value = entry
    formState.value.out_date = new Date()
      .toLocaleString('es-CO', {dateStyle: 'medium', timeStyle: 'short', hour12: true}),
      exitModal.value = true

  }
  
  function processError(error) {
    if (error.response?.status === 401) {
        $q.dialog({
          title: t('error_title'),
          message: t('global_missing_session') 
        })  
    } else {
      $q.dialog({
        title: t('error_title'),
        message: error.response?.data?.message ? error.response.data.message : error 
      })  
    }
  }
  
  function loadForms() {
    if (!exitModal.value) {
      formState.value = {
        supervisor_id: 666,
        worker_id: 0,
        in_date: newIngreso.value ? new Date().toLocaleString('es-CO', {dateStyle: 'medium', timeStyle: 'short', hour12: true}) : 0,
        out_date: exitModal.value ? new Date().toLocaleString('es-CO', {dateStyle: 'medium', timeStyle: 'short', hour12: true}) : 0,
        in_photo_check: '',
        out_photo_check: '',
        project_id: 0,
        in_coordinates: {},
        out_coordinates: {},
        in_photo_location: '',
        out_photo_location: ''
      }  
      loadUsers()
    }
    
    loadLocation()
    
  }
  
  function loadLocation() {
    $q.loading.show({
      delay: 400, // ms
      message: t('loading_location')
    })
    const success = async (position) => {
      const latitude  = position.coords.latitude
      const longitude = position.coords.longitude
      location.value = {lat: latitude, lon: longitude}
      //console.log(latitude + "  " + longitude)
      let imgUrl = mapBoxbaseUrl + `(${longitude},${latitude})/${longitude},${latitude},16,0/300x200?access_token=${mapBoxKey}`
      const image = await fetch(imgUrl)
      locationImgBlob = await image.blob()
      const internalImgUrl = URL.createObjectURL(locationImgBlob)
      //now we set the form fields
      if (newIngreso.value === true) {
        originalLocationImages.in = locationImgBlob
        formState.value.in_photo_location = internalImgUrl
        formState.value.in_coordinates = {
          'lat': latitude,
          'lon': longitude
        }
      } else {
        originalLocationImages.out = locationImgBlob
        formState.value.out_photo_location = internalImgUrl
        formState.value.out_coordinates = {
          'lat': latitude,
          'lon': longitude
        }
      }
  
      $q.loading.hide()
    }

    const error = (err) => {
      $q.loading.hide()
      console.log(err)
    };

    // This will open permission popup
    navigator.geolocation.getCurrentPosition(success, error);
}
</script>

<template>
  <q-card class="my-card" @click="supervisorModal = true">
    <q-parallax
      :src="assetsRoute + 'images/clock.avif'"
      :height="150"
    />

    <q-card-section>
      <div class="text-h6">{{ t('mng_act_card_title') }}</div>
      <div class="text-subtitle2">{{ t('mng_act_card_subtitle') }}</div>
    </q-card-section>
  </q-card>

  <q-dialog v-model="supervisorModal" full-width full-height>
    <q-card>
      <q-card-section>
        <div class="text-h6">{{ t('mng_act_modal_title') }}</div>
      </q-card-section>

      <q-separator/>
      <q-separator/>

      <q-card-section style="max-height: 80vh" class="scroll">
        <q-list bordered class="rounded-borders" style="max-height: 68vh">
          <!--<q-item-label header>{{ t('mng_act_modal_list_title') }}</q-item-label>

          <q-separator spaced/>-->
          <q-item v-for="registry in attendance" :key="registry.id">
            <q-btn class="full-width" @click="registerWorkerExit(registry)">
              <template v-slot:default>
                <q-item-section avatar top>
                  <q-avatar>
                    <img :src="registry.in_photo_check">
                  </q-avatar>
                </q-item-section>
                <q-item-section top>
                  <!--<q-item-label lines="1" class="q-mt-xs text-body2 text-weight-bold text-primary text-uppercase">
                    <span>{{user.fullname}}</span>
                  </q-item-label>-->
                  <q-item-label>{{ registry.fullname }}</q-item-label>
                  <q-item-label caption lines="1">{{ longToDateTime(registry.in_date) }}</q-item-label>
    
                </q-item-section>
                <q-item-section top side>
                <div class="text-grey-8 q-gutter-xs">
                  <q-btn size="12px" flat dense round icon="transfer_within_a_station"
                         />
                </div>
              </q-item-section>
              </template>
            </q-btn>
          </q-item>
        </q-list>
      </q-card-section>

      <q-separator/>

      <q-card-actions align="right">
        <q-btn flat :label="t('mng_act_btn_close')" color="primary" v-close-popup/>
        <q-btn flat :label="t('mng_act_btn_register')" color="positive" @click="newIngreso = true"/>
      </q-card-actions>
    </q-card>
  </q-dialog>

  <q-dialog v-model="exitModal" @before-show="loadForms">
    <q-card class="card-style">
      <q-form @submit.prevent="confirmExit = true">
        <q-card-section>
          <div class="text-h6">{{ t('mng_act_exit_modal_title') }}</div>
          <div class="text-subtitle1">
            <!--{{t('mng_act_exit_modal_confirm', { fullname: formState.fullname }) }}-->
            {{formState.out_date}}
          </div>
        </q-card-section>
        <q-separator inset/>
        <q-img
            :src="formState.out_photo_location"
            spinner-color="white"
            class="image"
          />
        <q-card-section class="column q-gutter-md">
          <!--<q-input
            v-model="formState.out_date"
            :label="t('mng_act_new_register_sub_time')"
            readonly
          ></q-input>-->
          <q-uploader
            style="width: 97%"
            label="Toma una foto para validacion"
            accept="image/*"
            @added="(files, mode) => addedFile(files, 1)"
            capture="user"
            hide-upload-btn
          >
            <template v-slot:header="scope">
              <div class="row no-wrap items-center q-pa-sm q-gutter-xs">
                <div class="col" v-if="scope.queuedFiles.length > 0" icon="clear_all" @click="scope.removeQueuedFiles" round dense flat >
                  <q-tooltip>Clear All</q-tooltip>
                </div>
                
                <div class="col" v-if="scope.canAddFiles" type="a" icon-right="add_box" label="Pick Files" dense flat>
                  <span class="text-h6">{{ t('mng_act_new_register_upload') }}</span>
                  <q-uploader-add-trigger></q-uploader-add-trigger>
                </div>
                
              </div>
            </template>
          </q-uploader>  
        </q-card-section>
        <q-card-actions align="right">
          <!--<q-btn flat>Cancel</q-btn>
          <q-btn color="primary" type="submit">Create Account</q-btn>-->
          <q-btn flat label="Cancelar" color="negative" v-close-popup/>
          <q-btn flat label="Guardar" color="positive" type="submit"/>
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>

  <q-dialog v-model="newIngreso" @before-show="loadForms">
    <q-card class="card-style">
      <q-form @submit.prevent="submitForm">
        <q-card-section>
          <div class="text-h6">{{ t('mng_act_new_register_title')}}</div>
          <div class="text-subtitle1">
            {{ formState.in_date }}
          </div>
        </q-card-section>
        <q-separator inset/>
        <q-img
            :src="formState.in_photo_location"
            spinner-color="white"
            class="image"
          />
        <q-card-section class="column q-gutter-md">
          <q-select
            filled
            v-model="formState.worker_id"
            use-input
            hide-selected
            fill-input
            input-debounce="0"
            :options="users"
            :option-value="'id'"
            :option-label="'fullname'"
            @filter="filterFn"
            :hint="t('mng_act_new_register_sub_select')"
          >
            <template v-slot:no-option>
              <q-item>
                <q-item-section class="text-grey">
                  No results
                </q-item-section>
              </q-item>
            </template>
          </q-select>
          
          <q-select
            filled
            v-model="formState.project_id"
            use-input
            hide-selected
            fill-input
            input-debounce="0"
            :options="projects"
            :option-value="'id'"
            :option-label="'name'"
            @filter="filterFn"
            :hint="t('mng_act_select_project')"
          >
            <template v-slot:no-option>
              <q-item>
                <q-item-section class="text-grey">
                  No results
                </q-item-section>
              </q-item>
            </template>
          </q-select>
          <q-uploader
            style="width: 97%"
            url="http://localhost:4444/upload"
            label="Toma una foto para validacion"
            accept="image/*"
            @added="(files, mode) => addedFile(files, 0)"
            hide-upload-btn
            capture="user"
          >
            <template v-slot:header="scope">
              <div class="row no-wrap items-center q-pa-sm q-gutter-xs">
                <div class="col" v-if="scope.queuedFiles.length > 0" icon="clear_all" @click="scope.removeQueuedFiles" round dense flat >
                  <q-tooltip>Clear All</q-tooltip>
                </div>
                <div class="col" v-if="scope.canAddFiles" type="a" icon-right="add_box" dense flat>
                  <span class="text-h6">{{ t('mng_act_new_register_upload') }}</span>
                  <q-uploader-add-trigger></q-uploader-add-trigger>
                </div>
              </div>
            </template>
          </q-uploader>
        </q-card-section>
        <q-card-actions align="right">
          <!--<q-btn flat>Cancel</q-btn>
          <q-btn color="primary" type="submit">Create Account</q-btn>-->
          <q-btn flat :label="t('global_cancel')" color="negative" v-close-popup/>
          <q-btn flat :label="t('global_save')" color="positive" type="submit"/>
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>

  <q-dialog v-model="confirmCreate" persistent>
    <q-card>
      <q-card-section class="row items-center">
        <q-avatar icon="signal_wifi_off" color="primary" text-color="white"/>
        <span class="q-ml-sm">{{ t('mng_act_confim_entry_text') }}</span>
      </q-card-section>

      <q-card-actions align="right">
        <!--<q-btn flat :label="t('global_cancel')" color="negative" v-close-popup/>
        <q-btn flat :label="t('global_save')" color="positive" @click="saveAttendance(0)"/>-->
        <q-btn flat :label="t('global_cancel')" color="negative" v-close-popup/>
        <q-btn flat :label="t('global_save')" color="positive" @click="saveAttendance(0)"/>
      </q-card-actions>
    </q-card>
  </q-dialog>

  <q-dialog v-model="confirmExit" persistent>
    <q-card>
      <q-card-section class="row items-center">
        <q-avatar icon="signal_wifi_off" color="primary" text-color="white"/>
        <span class="q-ml-sm">{{ t('mng_act_confim_exit_text') }}</span>
      </q-card-section>

      <q-card-actions align="right">
        <q-btn flat :label="t('global_cancel')" color="negative" v-close-popup/>
        <q-btn flat :label="t('global_save')" color="positive" @click="saveAttendance(1)"/>
      </q-card-actions>
    </q-card>
  </q-dialog>

</template>


<style scoped lang="scss">
  .image {
    height: 280px;
    margin: 16px auto 0 auto;
  }
  .card-style{
    max-width: 90vw;
    width: 90vw;
  }
</style>