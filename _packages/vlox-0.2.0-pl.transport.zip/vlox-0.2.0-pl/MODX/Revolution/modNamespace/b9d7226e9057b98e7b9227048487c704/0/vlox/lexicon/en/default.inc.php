<?php

$_lang['vlox.menu'] = 'Vlox';
$_lang['vlox.manage.page_title'] = 'Vlox';
$_lang['vlox.menu_desc'] = 'Webpack components manager';
