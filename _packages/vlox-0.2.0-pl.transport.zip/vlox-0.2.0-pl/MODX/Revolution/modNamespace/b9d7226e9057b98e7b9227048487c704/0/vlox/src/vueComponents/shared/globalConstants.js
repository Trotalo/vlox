/*
 * This file is part of VloX.
 *
 * Copyright (c) TROTALO, SAS. All Rights Reserved.
 *
 * For complete copyright and license information, see the COPYRIGHT and LICENSE
 * files found in the top-level directory of this distribution.
 */
import Vue from "vue";

//TODO places to automate vars
Vue.prototype.$restRoute = '/assets/components/vlox';
//Vue.prototype.$restRoute = '/vlox/assets/components/vlox';

