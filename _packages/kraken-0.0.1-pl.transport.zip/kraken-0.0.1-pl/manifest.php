<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'bd796de347aabd4b2e7a5965669f83e8',
      'native_key' => 'kraken',
      'filename' => 'modNamespace/e0a4b413b012e46d83c0bd4f2f7db21b.vehicle',
      'namespace' => 'kraken',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'be741aa15b0af2ea59bc6ee1f784fbf2',
      'native_key' => NULL,
      'filename' => 'modCategory/7bd53f533819f9af069c24dedec753f7.vehicle',
      'namespace' => 'kraken',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8545590aa84f68b865ea12d0e6168777',
      'native_key' => 'Monster',
      'filename' => 'modMenu/4c07723d76284bee71df311a1b4a5628.vehicle',
      'namespace' => 'kraken',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '19b9328b923f2759ad65cd41152d5d49',
      'native_key' => 'Kraken blocks',
      'filename' => 'modMenu/eef3423abed5d4a5e9419cf12af8d061.vehicle',
      'namespace' => 'kraken',
    ),
  ),
);