<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4cb7a87cbd30d8cf09930d3cb69c2adc',
      'native_key' => 'kraken',
      'filename' => 'modNamespace/5f4709f3e1c46ba868672de26476e223.vehicle',
      'namespace' => 'kraken',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '408adacc95056a4144d13fcf29e449b3',
      'native_key' => NULL,
      'filename' => 'modCategory/2de72f7eeece2dde025684c98804120f.vehicle',
      'namespace' => 'kraken',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '843271537d0eebc4da4c335eea8bfd47',
      'native_key' => 'Monster',
      'filename' => 'modMenu/297a495c0fb440146832b459cc79ee9e.vehicle',
      'namespace' => 'kraken',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5c6eff9cafcfcdd5a2f1ceb78fff5369',
      'native_key' => 'Kraken blocks',
      'filename' => 'modMenu/0b8be43f9a5b680db8a39f2626a0d2b4.vehicle',
      'namespace' => 'kraken',
    ),
  ),
);