<?php
/**
 * @package kraken
 */
class krakenBlocksResourceContent extends xPDOSimpleObject {}
?>