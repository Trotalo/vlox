<?php
/**
 * @package kraken
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/krakenblock.class.php');
class krakenBlock_mysql extends krakenBlock {}
?>