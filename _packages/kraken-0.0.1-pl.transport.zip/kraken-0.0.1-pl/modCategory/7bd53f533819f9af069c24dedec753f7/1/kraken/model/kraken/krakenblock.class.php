<?php
/**
 * @package kraken
 */
class krakenBlock extends xPDOSimpleObject {}
?>