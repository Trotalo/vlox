  <template>
  <p>Otra marikada diferente!</p>
  </template>
  <script>
  module.exports = {
    name: "adsfasfsafsaf234-8",
    data() {
      return {
        krakenBlock: []
      };
    },
  };
  </script>
  <style scope></style>