  <template>
  <p>Create some content!</p>
  </template>
  <script>
  module.exports = {
    name: "un_elefando-1",
    data() {
      return {
        krakenBlock: []
      };
    },
  };
  </script>
  <style scope></style>