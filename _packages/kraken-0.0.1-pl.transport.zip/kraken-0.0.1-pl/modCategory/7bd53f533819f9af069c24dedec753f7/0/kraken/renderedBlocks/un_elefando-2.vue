 <template>
  <div id="headerTrotalo">
        <b-navbar toggleable="lg" fixed="top">
            <b-navbar-brand href="#">
                <img src="assets/images/logoMenu.svg" class="d-inline-block align-top" alt="logoTrotalo" fixed="top">
            </b-navbar-brand>
            <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>
            <b-collapse id="nav-collapse" is-nav>
                <b-navbar-nav class="ml-auto">
                  <b-nav-item 
                    href="https://calendly.com/cami-trotalo/site-budget" 
                    target="_blank">Contact us
                  </b-nav-item>
                  <b-nav-item href="#ecosystem">Our Work</b-nav-item>
                  <b-nav-item href="#enterprenours">Businesses</b-nav-item>
                  <b-nav-item href="#corporate">Our technology</b-nav-item>
                </b-navbar-nav>
            </b-collapse>
        </b-navbar>
    </div>
  </template>
  <script>
  module.exports = {
    name: "un_elefando-2",
    data() {
      return {
        krakenBlock: []
      };
    },
  };
  </script>
  <style scope>#headerTrotalo {
  font-family: Mount;
}
#headerTrotalo .nav-link {
  color: #13435E;
  font-size: 21px;
}
#headerTrotalo .navbar {
  background-color: white;
}
</style>