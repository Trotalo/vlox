  <template>
  <p>Create some content!</p>
  </template>
  <script>
  module.exports = {
    name: "adsfasfsafsaf234-2",
    data() {
      return {
        krakenBlock: []
      };
    },
  };
  </script>
  <style scope></style>