  <template>
  <p>Vaian a</p>
  </template>
  <script>
  module.exports = {
    name: "adsfasfsafsaf-4",
    data() {
      return {
        krakenBlock: []
      };
    },
  };
  </script>
  <style scope></style>