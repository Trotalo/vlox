  <template>
  <p>Vaian a</p>
  </template>
  <script>
  module.exports = {
    name: "adsfasfsafsaf-5",
    data() {
      return {
        krakenBlock: []
      };
    },
  };
  </script>
  <style scope></style>