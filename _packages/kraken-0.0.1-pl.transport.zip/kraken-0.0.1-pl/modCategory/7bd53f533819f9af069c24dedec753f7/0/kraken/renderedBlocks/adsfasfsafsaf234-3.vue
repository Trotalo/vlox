  <template>
  <p>Create some content!</p>
  </template>
  <script>
  module.exports = {
    name: "adsfasfsafsaf234-3",
    data() {
      return {
        krakenBlock: []
      };
    },
  };
  </script>
  <style scope></style>