Progbando un puto readme
