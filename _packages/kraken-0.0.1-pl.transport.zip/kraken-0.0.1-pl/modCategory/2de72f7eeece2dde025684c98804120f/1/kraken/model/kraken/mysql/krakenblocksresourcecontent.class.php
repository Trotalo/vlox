<?php
/**
 * @package kraken
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/krakenblocksresourcecontent.class.php');
class krakenBlocksResourceContent_mysql extends krakenBlocksResourceContent {}
?>