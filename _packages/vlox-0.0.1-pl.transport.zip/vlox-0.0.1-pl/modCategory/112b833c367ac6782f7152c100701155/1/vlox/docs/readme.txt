# Welcome to ModX Kraken extra

Kraken is an extra for the ModX CMS that allows a seamless integration
between ModX and Vue (2.6.14)

It works by providing a base template that includes most of the boilerplate
code and libraries needed to run vue projects, along the bootstrap library to
help you get your sites up and running in no time.

Just download the package file vlox-0.0.1-pl.transport.zip located inside
_packages and add it to your modx installation.

check https://www.youtube.com/channel/UCV2IC4qdyMnL5W2HrJ1d9Vw for content on how to use it
and various examples of this extra
