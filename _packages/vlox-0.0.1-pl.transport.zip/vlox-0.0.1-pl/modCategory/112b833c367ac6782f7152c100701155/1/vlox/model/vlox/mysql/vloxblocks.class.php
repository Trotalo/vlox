<?php
require_once (dirname(__DIR__) . '/vloxblocks.class.php');
class vloxBlocks_mysql extends vloxBlocks {}