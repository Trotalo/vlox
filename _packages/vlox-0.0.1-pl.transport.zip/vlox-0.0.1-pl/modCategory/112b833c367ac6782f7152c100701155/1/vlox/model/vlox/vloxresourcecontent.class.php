<?php
class vloxResourceContent extends xPDOSimpleObject {}