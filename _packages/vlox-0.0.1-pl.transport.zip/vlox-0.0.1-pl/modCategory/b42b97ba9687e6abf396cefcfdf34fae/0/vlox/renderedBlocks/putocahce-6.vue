  <template>
  <p>Create some content! kiwichon!</p>
  </template>
  <script>
  module.exports = {
    name: "putocahce-6",
    data() {
      return {
        vloxBlock: []
      };
    },
  };
  </script>
  <style scope></style>