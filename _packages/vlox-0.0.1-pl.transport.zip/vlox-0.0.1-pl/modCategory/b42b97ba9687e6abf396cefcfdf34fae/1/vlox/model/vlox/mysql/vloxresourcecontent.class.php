<?php
require_once (dirname(__DIR__) . '/vloxresourcecontent.class.php');
class vloxResourceContent_mysql extends vloxResourceContent {}