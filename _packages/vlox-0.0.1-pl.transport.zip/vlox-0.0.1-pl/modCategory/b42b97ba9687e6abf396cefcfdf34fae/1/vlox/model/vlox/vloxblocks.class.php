<?php
class vloxBlocks extends xPDOSimpleObject {}